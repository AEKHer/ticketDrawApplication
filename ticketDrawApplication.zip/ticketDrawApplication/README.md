# ticketDrawApplication
Raffle software with C# and Guna2 Framework for number-based raffles using tickets

![screenshot (1)](https://user-images.githubusercontent.com/78161216/218282158-3f853951-3514-4162-b73a-4bcd161c2839.png)
![screenshot (2)](https://user-images.githubusercontent.com/78161216/218282159-842800a8-d0ed-426c-a6ac-22347e5453ca.png)
![screenshot (3)](https://user-images.githubusercontent.com/78161216/218282160-4d99d2e3-793e-46ba-a59d-441f78f39f6c.png)
